fx_version 'cerulean'

game "gta5"

author "Project Sloth & OK1ez"
version '2.2.2'

lua54 'yes'

ui_page 'html/index.html'
-- ui_page 'http://localhost:5173/' --for dev

client_script {
  '@PolyZone/client.lua',
  '@PolyZone/CircleZone.lua',
  '@PolyZone/BoxZone.lua',
  'client/**',
}
server_script {
  "server/**",
}
shared_script {
  "shared/**",
  '@ox_lib/init.lua',
}

files {
  'html/**',
  'locales/*.json',
  'sounds/panicbutton.ogg',
  'sounds/dispatch.ogg',
 --'sounds/robberysound.ogg', 
 'sounds/bankrobbery.ogg',
 'sounds/drugsale.ogg',
 'sounds/emsdown.ogg',
 'sounds/jewelrobbery.ogg',
 'sounds/officerdown.ogg',
 'sounds/panicbutton.ogg',
 'sounds/requestbackup.ogg',
 'sounds/robbery.ogg',
 'sounds/shotsfired.ogg',
 'sounds/storerobbery.ogg',
 'sounds/emsbackup.ogg',
 'sounds/civdown.ogg',
  'sounds/civpdhelp.ogg',
  'sounds/civrequesthelp.ogg',
  'sounds/anonpdhelp.ogg',
  'sounds/anonemshelp.ogg',
  'sounds/dispatchattach.ogg',

}

ox_lib 'locale' -- v3.8.0 or above
