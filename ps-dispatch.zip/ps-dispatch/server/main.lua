local QBCore = exports['qb-core']:GetCoreObject()

local calls = {}
local callCount = 0

-- Functions
exports('GetDispatchCalls', function()
    return calls
end)

-- Events
RegisterServerEvent('ps-dispatch:server:notify', function(data)
    local src = source
    callCount = callCount + 1
    data.id = callCount
    -- Try to track who the "victim" of this dispatch is so we
    -- can later send them an "EMS is on the way" notification
    -- when an EMS unit attaches. Prefer an explicit victim if
    -- provided, otherwise derive it from pedNetId when possible,
    -- and finally fall back to the source player (if not server).
    if not data.victim or data.victim == 0 then
        local victim

        if data.pedNetId then
            local ped = NetworkGetEntityFromNetworkId(data.pedNetId)
            if ped and ped ~= 0 and DoesEntityExist(ped) then
                local owner = NetworkGetEntityOwner(ped)
                if owner and owner ~= 0 then
                    victim = owner
                end
            end
        end

        if not victim and src ~= 0 then
            victim = src
        end

        data.victim = victim
    end
    data.time = os.time() * 1000
    data.units = {}
    data.responses = {}

    -- Normalise jobs so both job *names* and job *types* are present.
    -- This ensures the NUI tray filter (which checks job.type like 'leo'/
    -- 'ems') and the in-game checks (which often use job names like
    -- 'police'/'ambulance') all see the same dispatches.
    if data.jobs and type(data.jobs) == 'table' then
        local seen, normalised = {}, {}

        local function addJob(job)
            if job and not seen[job] then
                seen[job] = true
                normalised[#normalised+1] = job
            end
        end

        for _, job in ipairs(data.jobs) do
            addJob(job)
            local lower = string.lower(job)
            if lower == 'police' or lower == 'leo' then
                addJob('leo')
            elseif lower == 'ambulance' or lower == 'ems' then
                addJob('ems')
            end
        end

        data.jobs = normalised
    end

    if #calls > 0 then
        if calls[#calls] == data then
            return
        end
    end
        
    if #calls >= Config.MaxCallList then
        table.remove(calls, 1)
    end

    calls[#calls + 1] = data

    TriggerClientEvent('ps-dispatch:client:notify', -1, data)
end)

RegisterServerEvent('ps-dispatch:server:attach', function(id, player)
    for i=1, #calls do
        if calls[i]['id'] == id then
            for j = 1, #calls[i]['units'] do
                if calls[i]['units'][j]['citizenid'] == player.citizenid then
                    return
                end
            end
            calls[i]['units'][#calls[i]['units'] + 1] = player

            if player.job and player.job.type == 'ems' and calls[i].victim and not calls[i].emsNotified then
                calls[i].emsNotified = true
                TriggerClientEvent('ps-dispatch:client:emsOnTheWay', calls[i].victim, calls[i], player)
            end
            return
        end
    end
end)

RegisterServerEvent('ps-dispatch:server:detach', function(id, player)
    for i = #calls, 1, -1 do
        if calls[i]['id'] == id then
            if calls[i]['units'] and (#calls[i]['units'] or 0) > 0 then
                for j = #calls[i]['units'], 1, -1 do
                    if calls[i]['units'][j]['citizenid'] == player.citizenid then
                        table.remove(calls[i]['units'], j)
                    end
                end
            end
            return
        end
    end
end)

RegisterServerEvent('ps-dispatch:server:clearCalls', function()
    calls = {}
end)

-- Callbacks
lib.callback.register('ps-dispatch:callback:getLatestDispatch', function(source)
    return calls[#calls]
end)

lib.callback.register('ps-dispatch:callback:getCalls', function(source)
    return calls
end)

-- Commands
lib.addCommand('dispatch', {
    help = locale('open_dispatch')
}, function(source, raw)
    TriggerClientEvent("ps-dispatch:client:openMenu", source, calls)
end)

lib.addCommand('911', {
    help = 'Send a message to 911',
    params = { { name = 'message', type = 'string', help = '911 Message' }},
}, function(source, args, raw)
    local fullMessage = raw:sub(5)
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, fullMessage, "911", false)
end)
lib.addCommand('911a', {
    help = 'Send an anonymous message to 911',
    params = { { name = 'message', type = 'string', help = '911 Message' }},
}, function(source, args, raw)
    local fullMessage = raw:sub(5)
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, fullMessage, "911", true)
end)

lib.addCommand('311', {
    help = 'Send a message to 311',
    params = { { name = 'message', type = 'string', help = '311 Message' }},
}, function(source, args, raw)
    local fullMessage = raw:sub(5)
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, fullMessage, "311", false)
end)

lib.addCommand('311a', {
    help = 'Send an anonymous message to 311',
    params = { { name = 'message', type = 'string', help = '311 Message' }},
}, function(source, args, raw)
    local fullMessage = raw:sub(5)
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, fullMessage, "311", true)
end)

lib.addCommand('emsbackup', {
    help = 'Request EMS backup (alerts police)',
}, function(source, args, raw)
    TriggerClientEvent('ps-dispatch:client:emsbackup', source)
end)

lib.addCommand('backup', {
    help = 'Request police backup',
}, function(source, args, raw)
    TriggerClientEvent('ps-dispatch:client:officerbackup', source)
end)

-- Set the player's callsign metadata from ps-dispatch
RegisterNetEvent('ps-dispatch:server:setCallsign', function(callsign)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local pdata = Player.PlayerData or {}
    local job = pdata.job or {}

    -- Restrict to emergency jobs (police / EMS)
    if job.type ~= 'leo' and job.type ~= 'ems' and job.name ~= 'police' and job.name ~= 'ambulance' and job.name ~= 'ems' then
        return
    end

    callsign = tostring(callsign or ''):gsub('^%s+', ''):gsub('%s+$', '')
    if callsign == '' then return end

    if #callsign > 16 then
        callsign = callsign:sub(1, 16)
    end

    Player.Functions.SetMetaData('callsign', callsign)

    TriggerClientEvent('ps-dispatch:client:updateCallsign', src, callsign)
end)

-- Admin-only test commands for dispatch sounds (use ACE permissions)
-- Example server.cfg: add_ace group.admin command.ps-dispatch-test allow

local function isAdmin(source)
    return IsPlayerAceAllowed(source, 'command.ps-dispatch-test')
end

RegisterCommand('test_officerdown', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:officerdown', source)
end, false)

RegisterCommand('test_backup', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:officerbackup', source)
end, false)

-- Test emergency call dispatches (use the full 911/311 flow)
RegisterCommand('test_911', function(source)
    if source == 0 or not isAdmin(source) then return end
    -- Simulate a normal /911 call from this player, but bypass cooldown
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, 'TEST 911 DISPATCH', '911', false, true)
end, false)

RegisterCommand('test_311', function(source)
    if source == 0 or not isAdmin(source) then return end
    -- Simulate a normal /311 call from this player, but bypass cooldown
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, 'TEST 311 DISPATCH', '311', false, true)
end, false)

RegisterCommand('test_911a', function(source)
    if source == 0 or not isAdmin(source) then return end
    -- Simulate an anonymous /911a call from this player, bypassing cooldown
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, 'TEST 911a DISPATCH', '911', true, true)
end, false)

RegisterCommand('test_311a', function(source)
    if source == 0 or not isAdmin(source) then return end
    -- Simulate an anonymous /311a call from this player, bypassing cooldown
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, 'TEST 311a DISPATCH', '311', true, true)
end, false)

RegisterCommand('test_emsdown', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:emsdown', source)
end, false)

RegisterCommand('test_emsbackup', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testEmsBackup', source)
end, false)

RegisterCommand('test_storerobbery', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testStoreRobbery', source)
end, false)

RegisterCommand('test_bankrobbery', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testFleecaBankRobbery', source)
end, false)

RegisterCommand('test_vangelico', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testVangelicoRobbery', source)
end, false)

RegisterCommand('test_shotsfired', function(source)
    if source == 0 or not isAdmin(source) then return end
    -- Trigger the standard shooting alert (codeName = 'shooting')
    -- so you can test the dispatch card and shotsfired.ogg audio
    TriggerClientEvent('ps-dispatch:client:testShooting', source)
end, false)

RegisterCommand('test_drugsale', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testDrugSale', source)
end, false)

RegisterCommand('test_shotsfired', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testShooting', source)
end, false)

-- Additional /test commands for other dispatch types
RegisterCommand('test_vehicletheft', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testVehicleTheft', source)
end, false)

RegisterCommand('test_vehicleshots', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testVehicleShooting', source)
end, false)

RegisterCommand('test_hunting', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testHunting', source)
end, false)

RegisterCommand('test_speeding', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testSpeeding', source)
end, false)

RegisterCommand('test_fight', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testFight', source)
end, false)

RegisterCommand('test_prisonbreak', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testPrisonBreak', source)
end, false)

RegisterCommand('test_paletobank', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testPaletoBankRobbery', source)
end, false)

RegisterCommand('test_pacificbank', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testPacificBankRobbery', source)
end, false)

RegisterCommand('test_houserobbery', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testHouseRobbery', source)
end, false)

RegisterCommand('test_yachtheist', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testYachtHeist', source)
end, false)

RegisterCommand('test_suspicious', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testSuspiciousActivity', source)
end, false)

RegisterCommand('test_carjacking', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testCarJacking', source)
end, false)

RegisterCommand('test_civdown', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testInjuriedPerson', source)
end, false)

RegisterCommand('test_civdead', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testDeceasedPerson', source)
end, false)

RegisterCommand('test_officerdistress', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testOfficerInDistress', source)
end, false)

RegisterCommand('test_explosion', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testExplosion', source)
end, false)

RegisterCommand('test_artgallery', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testArtGalleryRobbery', source)
end, false)

RegisterCommand('test_humane', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testHumaneRobbery', source)
end, false)

RegisterCommand('test_trainrobbery', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testTrainRobbery', source)
end, false)

RegisterCommand('test_vanrobbery', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testVanRobbery', source)
end, false)

RegisterCommand('test_undergroundrobbery', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testUndergroundRobbery', source)
end, false)

RegisterCommand('test_drugboat', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testDrugBoatRobbery', source)
end, false)

RegisterCommand('test_unionrobbery', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testUnionRobbery', source)
end, false)

RegisterCommand('test_carboosting', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testCarBoosting', source)
end, false)

RegisterCommand('test_signrobbery', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testSignRobbery', source)
end, false)

RegisterCommand('test_bobcat', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:testBobcatSecurityHeist', source)
end, false)

-- Test phone-based emergency calls and their custom sounds
RegisterCommand('test_911', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, 'Test 911 call', '911', false, true)
end, false)

RegisterCommand('test_911a', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, 'Test anonymous 911 call', '911', true, true)
end, false)

RegisterCommand('test_311', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, 'Test 311 call', '311', false, true)
end, false)

RegisterCommand('test_311a', function(source)
    if source == 0 or not isAdmin(source) then return end
    TriggerClientEvent('ps-dispatch:client:sendEmergencyMsg', source, 'Test anonymous 311 call', '311', true, true)
end, false)

