(function () {
  const THEME_POLICE = 'theme-police';
  const THEME_EMS = 'theme-ems';
  const THEME_EMS_OVERRIDE = 'theme-ems-override';

  // Remember the player's job theme so we can
  // temporarily switch to EMS for medic-down,
  // then restore it afterwards.
  let currentPlayer = null;

  function getBody() {
    return document.body || null;
  }

  function applyJobTheme(player) {
    const body = getBody();
    if (!body) return;

    body.classList.remove(THEME_POLICE, THEME_EMS);

    if (!player || !player.job) return;

    const job = player.job;
    const type = (job.type || '').toLowerCase();
    const name = (job.name || '').toLowerCase();

    if (type === 'leo' || name === 'police') {
      body.classList.add(THEME_POLICE);
    } else if (type === 'ems' || name === 'ambulance' || name === 'ems') {
      body.classList.add(THEME_EMS);
    }
  }

  function handleNewCall(payload) {
    const body = getBody();
    if (!body) return;

    const callWrapper = payload.data || payload;
    const call = callWrapper && (callWrapper.data || callWrapper);

    if (call) {
      // Treat all EMS-focused dispatches (including /311 calls,
      // person injured, medic down, EMS backup, EMS response, etc.)
      // as EMS-themed, even when viewed by police.
      const codeName = (call.codeName || '').toLowerCase();
      const code = (call.code || '').toString();

      const rawJobs = Array.isArray(call.jobs) ? call.jobs : [];
      const jobs = rawJobs.map(function (j) {
        return (j || '').toString().toLowerCase();
      });

      const hasEmsJob = jobs.indexOf('ems') !== -1 || jobs.indexOf('ambulance') !== -1;
      const hasPoliceJob = jobs.indexOf('leo') !== -1 || jobs.indexOf('police') !== -1;

      // EMS dispatches that should ALWAYS use the EMS theme
      // for everyone (PD, EMS, civilians): injured/deceased
      // civilians, medic down, EMS response, and 311 calls.
      const emsGlobalCodeNames = {
        civdown: true,   // person injured
        civdead: true,   // deceased person
        emsdown: true,   // medic down
        emsresponse: true,
        '311call': true,
        '311acall': true,
      };

      const isEmsGlobalByCodeName = !!emsGlobalCodeNames[codeName];
      const isEmsByCode = code === '311';
      const hasOnlyEmsJobs = hasEmsJob && !hasPoliceJob;

      // Primary EMS dispatches:
      // - Explicit EMS-only jobs (no police)
      // - 311 calls
      // - Strong EMS-coded events above
      const isPrimaryEmsDispatch = isEmsGlobalByCodeName || isEmsByCode || hasOnlyEmsJobs;

      if (isPrimaryEmsDispatch) {
        body.classList.remove(THEME_POLICE);
        body.classList.add(THEME_EMS);
        body.classList.add(THEME_EMS_OVERRIDE);
        return;
      }
    }

    // For non-EMS calls, remove EMS override and restore job theme
    body.classList.remove(THEME_EMS_OVERRIDE);
    if (currentPlayer) {
      applyJobTheme(currentPlayer);
    }
  }

  window.addEventListener('message', function (event) {
    const payload = event.data;
    if (!payload) return;

    if (payload.action === 'setupUI') {
      const data = payload.data || payload;
      if (!data || !data.player) return;
      currentPlayer = data.player;
      applyJobTheme(currentPlayer);
      return;
    }

    if (payload.action === 'newCall') {
      handleNewCall(payload);
      return;
    }

    // When a unit attaches/detaches to a dispatch (either via E key
    // or the NUI Respond/Detach buttons), the Lua client notifies us
    // so we can visually mark that card with a glow.
    if (payload.action === 'markAttached' || payload.action === 'clearAttached') {
      const data = payload.data || payload;
      if (!data || typeof data.id === 'undefined') return;

      const id = String(data.id);

      // Both the toast-style card (top-right) and the full list
      // cards render the dispatch id as "#<id>" in a <p> element.
      // We find those and then walk up to the card container.
      const paragraphs = document.querySelectorAll('p');
      paragraphs.forEach(function (p) {
        const text = (p.textContent || '').trim();
        if (!text || text.charAt(0) !== '#') return;

        // Match "#123" exactly for this dispatch id.
        if (text === '#' + id) {
          const header = p.parentElement; // header row
          const card = header && header.parentElement; // card root (div or button)
          if (!card) return;

          if (payload.action === 'markAttached') {
            card.classList.add('dispatch-attached-glow');
          } else {
            card.classList.remove('dispatch-attached-glow');
          }
        }
      });

      return;
    }
  });
})();
