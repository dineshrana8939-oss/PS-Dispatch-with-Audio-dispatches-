-- FXVersion Version
fx_version 'adamant'
games {"rdr3","gta5"}
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

-- Client Scripts
client_script 'client/main.lua'

-- Server Scripts
server_script 'server/main.lua'

-- NUI Default Page
ui_page "client/html/index.html"

-- Files needed for NUI
-- DON'T FORGET TO ADD THE SOUND FILES TO THIS!
files {
    'client/html/index.html',
    -- Begin Sound Files Here...
    -- client/html/sounds/ ... .ogg
    --'client/html/sounds/demo.ogg',
    'client/html/sounds/panicbutton.ogg',
    'client/html/sounds/dispatch.ogg',
    'client/html/sounds/robberysound.ogg',
    'client/html/sounds/bankrobbery.ogg',
    'client/html/sounds/drugsale.ogg',
    'client/html/sounds/emsdown.ogg',      
    'client/html/sounds/jewelrobbery.ogg',
    'client/html/sounds/officerdown.ogg',
    'client/html/sounds/panicbutton.ogg',
    'client/html/sounds/requestbackup.ogg',
    'client/html/sounds/robbery.ogg',
    'client/html/sounds/shotsfired.ogg',
    'client/html/sounds/storerobbery.ogg',
    'client/html/sounds/emsbackup.ogg',
    'client/html/sounds/civdown.ogg',
    'client/html/sounds/civpdhelp.ogg',
    'client/html/sounds/civrequesthelp.ogg',    
    'client/html/sounds/anonpdhelp.ogg',
    'client/html/sounds/anonemshelp.ogg',
    'client/html/sounds/dispatchattach.ogg',
}
